---
--- ALTER_TYPE_ENUM
---

ALTER TYPE enum_test ADD VALUE 'zzz' AFTER 'baz';
ALTER TYPE enum_test ADD VALUE 'aaa' BEFORE 'foo';
